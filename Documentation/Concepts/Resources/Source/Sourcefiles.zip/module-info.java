/**
 * 
 */
/**
 * @author LK Test Solutions
 *
 */
module openTDKDemo {
	 requires transitive org.opentdk.api.base;
	 requires java.logging;
}